<?php
$username = $_POST['username'];
$password = $_POST['password'];

if($username&&$password)
  {
    $connect = mysql_connect('localhost','root','') or die("couldn't connect");
    mysql_select_db("project") or die("couldn't find db");

    $row = mysql_query("select * from phplogin where username = '$username';");
    $rows = mysql_fetch_row($row);
    $pass = $rows[1];
    
    if($pass == $password)
      {
	echo "login successful";
      }
    else
      {
	echo "wrong username or password";
      }
  }
  else
     die("please enter username and password");

?>
<h3><center>
<?php include("home.php"); ?>
</h3></center>