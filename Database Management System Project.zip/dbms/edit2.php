<html>
<head>
</head>
<body>
<h3>Edit User:  <?php echo $_REQUEST['roll_nos'];?></h3>
<form method="POST" action="change2.php" />
<table border="0" width="60%">


<tr><td width="30%">Roll No: </td><td><input type="text" name="newroll_no"
value="<?php echo $_REQUEST['roll_nos'];?>"></td></tr>

<tr><td width="30%">Semester: </td><td><input type="text" name="newsemester"
value="<?php echo $_REQUEST['semesters'];?>"></td></tr>

<tr><td width="30%">Course: </td><td><input type="text" name="newcourse"
value="<?php echo $_REQUEST['courses'];?>"></td></tr>

<tr><td width="30%">Syllabus: </td><td><input type="text" name="newsyllabus"
value="<?php echo $_REQUEST['syllabuss'];?>"></td></tr>

<tr><td width="30%">Name: </td><td><input type="text" name="newname"
value="<?php echo $_REQUEST['names'];?>"></td></tr></table>

<input type="submit" value="Save & Update" />
<input type="hidden" name="regn_no" value="<?php echo $_REQUEST['regn_nos'];?>">
</form>


</body>




</html>