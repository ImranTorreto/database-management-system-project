

<p>
<a href="home.php">Home</a> &nbsp &nbsp
<a href="form1.php">Student Details</a>