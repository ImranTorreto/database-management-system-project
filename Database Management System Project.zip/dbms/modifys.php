<?php
$regn_no = $_POST['regn_no'];
$roll_no = $_POST['roll_no'];
$semester = $_POST['semester'];
$course = $_POST['course'];
$syllabus = $_POST['syllabus'];
$name = $_POST['name'];

if($regn_no && $roll_no && $semester && $course && $syllabus && $name) 
{
	mysql_connect("localhost","root","") or die("We couldn't connect");
	
	mysql_select_db("project");
       
	
	mysql_query("INSERT INTO std_data(regn_no,roll_no,semester,course,syllabus,name) VALUES('$regn_no','$roll_no','$semester','$course','$syllabus','$name')"); 
	
	$registered = mysql_affected_rows();
	
	echo "$registered row was inserted";
       }
else
{
	echo "You have to complete the details.. ";

}
mysql_close();


?>