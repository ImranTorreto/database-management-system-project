<html>
<head>
<title> Choice </title>
</head>
<body>
  <center>
     <h1> Choose Your Option </h1>

<p><h2>
<a href="form1.php">First Sem Student Register</a>   </br>&nbsp
<a href="form2.php">Second Sem Student Register</a></br>&nbsp
<a href="form1.php">Third Sem Student Register</a></br>&nbsp
<a href="form1.php">Fourth Sem Student Register</a></br>&nbsp
<a href="form1.php">Fifth Sem Student Register</a></br>&nbsp
</h2>
 </center>
 </html>