<body bgcolor="Plum">
<?php
mysql_connect("localhost","root","") or die ("problem with connection");
mysql_select_db("project");
$result = mysql_query("SELECT *FROM std_data");
echo "<table width = \"90%\" align=center border=2>";
echo "<tr><td width=\"20%\" align=center bgcolor=\#FFB6C1\">Registration No</td>
<td width=\"20%\" align=center bgcolor=\#FFB6C1\">Roll No</td>
<td width=\"10%\" align=center bgcolor=\#FFB6C1\">Semester</td>
<td width=\"10%\" align=center bgcolor=\#FFB6C1\">Course</td>
<td width=\"10%\" align=center bgcolor=\#FFB6C1\">Syllabus</td>
<td width=\"40%\" align=center bgcolor=\#FFB6C1\">Name</td></tr>";
while($row=mysql_fetch_array($result)){
$regn_no = $row['regn_no'];
$roll_no = $row['roll_no'];
$semester = $row['semester'];
$course = $row['course'];
$syllabus = $row['syllabus'];
$name = $row['name'];
echo "<table width = \"90%\" align=center border=2>";
echo "<tr><td width=\"20%\">$regn_no</td>
<td width=\"20%\">$roll_no</td><td width=\"10%\">$semester</td><td width=\"10%\">$course</td><td width=\"10%\">$syllabus</td><td width=\"40%\">$name</td></tr>";
}
echo"</table>";
echo"</table>";
mysql_close();
?>
&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<h2 style="font-family:Algerian"><center><a href="home.php">Home</a></center></h2>
<footer><center>
  <p><marquee><h1 style="font-family:Algerian">Submitted By: Imran Khan</h1></marquee></p></center>
</footer> 
</body>