<html>
 <head>
</head>
<body bgcolor="pink">
<body bgcolor="Pink"><Center><h2><Font color="black"><marquee><h2 style="font-family:Algerian">Enter Student Details...!!!</h2></marquee></font></h2></center></body>
<center><img src="nehu12.jpg" style="width:1300px;height:250px"></center>

<form method="post" action="insert.php">

<table border="0" width="60%">
<tr><td width=15%">Registration No: </td><td><input type="text" name="regn_no" /></td></tr><br />
<tr><td width="10%">Roll No: </td><td><input type="text" name="roll_no" /></td></tr><br />
<tr><td width="10%">Semester: </td><td><input type="text" name="semester" /></td></tr><br />
<tr><td width="10%">Course: </td><td><input type="text" name="course" /></td></tr><br />  
<tr><td width="10%">Syllabus: </td><td><input type="text" name="syllabus" /></td></tr><br />
<tr><td width="10%">Name: </td><td><input type="text" name="name" /></td></tr><br />
</table>
<p>
<input type="submit" value="Register" />
<input type="reset" value="Clear" /><br />


</form>

 <a href="home.php">Home</a>



</body>
</html>