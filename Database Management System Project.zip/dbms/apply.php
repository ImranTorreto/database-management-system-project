<html>
 <head>
</head>
<body>
<h2>Enter Exam Details</h2>


<form method="post" action="subdata.php">

<table border="0" width="60%">
<tr><td width="10%">Roll No: </td><td><input type="text" name="roll_no" /></td></tr><br />
<tr><td width="10%">Sub ID: </td><td><input type="text" name="id" /></td></tr><br />
<tr><td width="10%">Sub Name: </td><td><input type="text" name="sname" /></td></tr><br />
<tr><td width="10%">Semester: </td><td><input type="text" name="semester" /></td></tr><br />

</table>
<p>
<input type="submit" value="register" />
<input type="reset" value="Cancel"   /><br />

</form>

 


</body>
</html>