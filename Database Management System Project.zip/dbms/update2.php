<?php
echo "<h3>Choose Registration No to Modify:</h3><p>";
mysql_connect("localhost","root","") or die ("problem with connection");
mysql_select_db("project");
$result = mysql_query("SELECT *FROM second");
echo "<table width = \"90%\" align=center border=2>";
echo "<tr><td width=\"20%\" align=center bgcolor=\"FFFF00\">Registration No</td>
<td width=\"20%\" align=center bgcolor=\"FFFF00\">Roll No</td>
<td width=\"10%\" align=center bgcolor=\"FFFF00\">Semester</td>
<td width=\"10%\" align=center bgcolor=\"FFFF00\">Course</td>
<td width=\"10%\" align=center bgcolor=\"FFFF00\">Syllabus</td>
<td width=\"40%\" align=center bgcolor=\"FFFF00\">Name</td></tr>";
while($row=mysql_fetch_array($result)){
$regn_no = $row['regn_no'];
$roll_no = $row['roll_no'];
$semester = $row['semester'];
$course = $row['course'];
$syllabus = $row['syllabus'];
$name = $row['name'];

echo "<tr><td align=center>
<a href=\"edit2.php? regn_nos=$regn_no&roll_nos=$roll_no&semesters=$semester&courses=$course&syllabuss=$syllabus&names=$name\">$regn_no</a></td>
<td>$roll_no</td><td>$semester</td><td>$course</td><td>$syllabus</td><td width=\"40%\">$name</td></tr>";
}
echo "</table>";
mysql_close();
?>
<center>
<h2>
<?php
 include("form2.php");
 ?>
 </h2>
 </center>