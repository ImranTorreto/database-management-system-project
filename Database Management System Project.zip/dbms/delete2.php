<?php
mysql_connect("localhost","root","") or die ("problem with connection");
mysql_select_db("project");
$result = mysql_query("DELETE FROM std_data WHERE regn_no='".$_REQUEST['regn_no']."'");
echo "the user has been deleted";
mysql_close();
?> 
<center>
<h2>
<?php
 include("view.php");
 ?>
 </h2>
 </center>