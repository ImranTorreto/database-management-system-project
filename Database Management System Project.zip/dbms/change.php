<?php
$regn_no = $_REQUEST['regn_no'];
$newroll_no = $_REQUEST['newroll_no'];
$newsemester = $_REQUEST['newsemester'];
$newcourse = $_REQUEST['newcourse'];
$newsyllabus = $_REQUEST['newsyllabus'];
$newname = $_REQUEST['newname'];
mysql_connect("localhost","root","") or die("could not connect");
mysql_select_db("project");
mysql_query("UPDATE std_data SET roll_no='$newroll_no', semester='$newsemester', course='$newcourse', syllabus='$newsyllabus', name='$newname'
WHERE regn_no='$regn_no'");
echo "values has been updated succesfully";
mysql_close();
?>
<center>
<h2>
<?php
 include("view.php");
 ?>
 </h2>
 </center>