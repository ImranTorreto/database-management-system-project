<html>
 <head>
</head>
<body>
<h2>Enter Student Details</h2>


<form method="post" action="modfys.php">

<table border="0" width="60%">
<tr><td width="10%">Registration No: </td><td><input type="text" name="regn_no" /></td></tr><br />
<tr><td width="10%">Roll No: </td><td><input type="text" name="roll_no" /></td></tr><br />
<tr><td width="10%">Semester: </td><td><input type ="text"  name="semester" /></td></tr><br />
<tr><td width="10%">Course: </td><td><input type="text" name="course" /></td></tr><br />
<tr><td width="10%">Syllabus:</td><td><input type="text" name="syllabus" /></td></tr><br />
<tr><td width="10%">Name: </td><td><input type="text" name="name" /></td></tr><br />
</table>
<p>
<input type="submit" value="register" />
<input type="reset" value="cancel" /><br />

</form>

 

</body>
</html>