<?php

mysql_connect("localhost", "root", "") or die("Problem with connection...");

mysql_select_db("project");

$result = mysql_query("SELECT * FROM users");

while($row = mysql_fetch_array($result)) {
	
	echo $row['Registration NO']." ".$row['Roll No']." ".$row['Semester']." ".$row['Course']." ".$row['Name'];
	
	echo "<br />";
}

mysql_close();
?>

<h3><center>
<?php include("form1.php"); ?>
</h3></center>




