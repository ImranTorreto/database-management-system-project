<p>
<a href="secondform.php">Create Student List</a>&nbsp
<a href="update2.php">Modify Student List</a>&nbsp
<a href="delete.php">Delete User</a>&nbsp
 