<p>
<head>


<title>Student Details</title></head>
<body bgcolor="Pink"><Center><h1><Font color="black"><marquee><h1 style="font-family:Algerian">Student Information System...!!!</h1></marquee></font></h1></center></body>


<center><img src="nehu13.jpg" style="width:1300px;height:300px"></center>
<h2>&nbsp &nbsp&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<a href="form.php">Create Student List</a>&nbsp &nbsp &nbsp &nbsp
<a href="update.php">Modify Student List</a>&nbsp &nbsp &nbsp &nbsp
<a href="delete.php">Delete Student Details</a>&nbsp &nbsp &nbsp &nbsp
<a href="view.php">View Student List</a> &nbsp &nbsp &nbsp
<a href="home.php">Home</a>&nbsp

</h2>
<footer><center>
  <p><Font color="black"><marquee><h1 style="font-family:Algerian">Submitted By: Imran Khan</h1></marquee></p></center>
</footer> 
 