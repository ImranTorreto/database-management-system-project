<html>
<head>
</head>
<body bgcolor="Pink">
<body bgcolor=""><Center><h1><Font color="black"><marquee><h1 style="font-family:Algerian">Student Information System...!!!</h1></marquee></font></h1></center></body>
<center><img src="nehu12.jpg" style="width:1300px;height:300px"></center>
<p>
<h3><center>
<a href="form.php">What To Do...New Page..!!!</a>


</h3></center>
</p> 
<footer><center>
  <p><marquee><h1 style="font-family:Algerian">Submitted By: Imran Khan</h1></marquee></p></center>
</footer> 
</body>
</html>