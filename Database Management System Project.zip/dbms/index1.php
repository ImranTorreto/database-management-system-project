<html>
<title> login</title>
<body>
<center>
<form  action='login.php' method='POST' >
  username:<input type='text' name='username'><br>
  password:<input type='password' name='password'><br>
  <input type='submit' value='login'>
  <input type='reset' value='cancel'>
  </form>
  </center>
  </body>  </html>
