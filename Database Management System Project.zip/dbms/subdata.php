<?php

$roll_no = $_POST['roll_no'];
$id = $_POST['id'];
$sname = $_POST['sname'];
$semester = $_POST['semester'];

if($roll_no && $id && $sname && $semester) 
{
	mysql_connect("localhost","root","") or die("We couldn't connect");
	
	mysql_select_db("project");
	
	mysql_query("INSERT INTO subject(roll_no,id,sname,semester) VALUES('$roll_no','$id','$sname','$semester')"); 
	
	$registered = mysql_affected_rows();
	
	echo "$registered row was inserted";
}
else
{
	echo "You have to complete the details.. ";

}
mysql_close();


?>